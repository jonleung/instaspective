$(document).ready(function() {

  $(function () {
     $('.antiscroll-wrap').antiscroll();
  });

})